# LICENSE AGREEMENT (EULA)

Last updated: 2026-03-20

### 1. Parties
This License Agreement (hereinafter referred to as the "Agreement") is entered into between you (an individual or legal entity) and Viacheslav A (hereinafter referred to as the "Rights Holder") for the use of the computer program: "Photo and Video File Manager" (hereinafter referred to as the "Program").

### 2. Program Functionality Description
The Program is designed for organizing and managing a media library, including:
   Sorting photo and video files by year and month of capture (based on metadata);
   Finding and deleting duplicate files based on hash sum calculation (checksums);
   Other functions described in the user documentation.

### 3. Exclusive Rights
The Program is the result of intellectual activity, to which the Rights Holder holds all exclusive rights. The Program is written in the C language and operates on Linux and Windows family operating systems. The Program's source code is a trade secret and is not subject to disclosure.

### 4. Subject of the Agreement
The Rights Holder grants you a non-exclusive (simple) license to install and use the Program in accordance with the terms of this Agreement within the territory of the Russian Federation and the countries of the European Union. The Rights Holder does not transfer exclusive rights to the Program to you.

### 5. License Types and Restrictions

5.1. Trial License:
   Validity Period: 3 (three) months from the date of first installation or launch of the Program.
   Functional Limitations: The Program processes no more than 10 (ten) files per single session.
   Purpose: Provided solely for the purpose of evaluation and testing of functionality. Not intended for commercial use or systematic processing of large volumes of data.

5.2. Paid License (Full):
   Validity Period: 1 (one) year from the date of license activation.
   Functionality: Full, without limitations on the number of processed files. All Program functions (sorting, hash-based duplicate search, etc.) are available in full.
   Territory of Use: RF, EU, USA.
   Activation Terms: The license is not tied to a specific workstation. There are no restrictions on the number of installations. Activation is performed by placing a special license file, signed (encrypted) with the Rights Holder's key, into the program directory.

### 6. Permitted Actions
You are permitted to:
   Install and run the Program on an unlimited number of computers running Linux and Windows operating systems that belong to you.
   Use the Program strictly in accordance with the acquired license for organizing a personal or corporate media library (depending on the type of license acquired).

### 7. Prohibited Actions
It is prohibited to:
   Perform decompilation, disassembly, or circumvent the Program's technical limitations (including attempts to remove the 10-file limit or extend the trial period).
   Modify, forge, or generate license files, or attempt to run the Program without a valid license file.
   Distribute (copy, transfer, rent out, sell sublicenses) the Program to third parties without the written consent of the Rights Holder.
   Use the Program to process files that violate the laws of the Russian Federation or EU countries (including materials of an extremist nature or that violate the copyrights of third parties).

### 8. Disclaimer of Warranties and Limitation of Liability
The Program is provided "as is." The Rights Holder does not warrant that the Program will operate uninterrupted or error-free, or that it will meet your specific requirements regarding sorting or detecting all possible duplicates.
   The Rights Holder shall not be liable for the accidental deletion of original files or loss of data resulting from the operation of the Program (it is recommended to create backup copies).
   Under no circumstances shall the Rights Holder be liable for any indirect damages, loss of data, or profits arising from the use or inability to use the Program.
   The Rights Holder's total liability under this Agreement is limited to the amount paid by you for the Program.

### 9. Termination
The Rights Holder has the right to terminate this Agreement unilaterally in the event of your violation of the terms of use, particularly regarding attempts to hack, reverse engineer, or forge license files.

### 10. Updates
The Rights Holder may release updates for the Program. The terms of this Agreement apply to all subsequent updates unless the update is accompanied by a new agreement.

### 11. Miscellaneous
If any provision of this Agreement is found to be invalid or contrary to the laws of any country of distribution, the remaining provisions shall remain in force. This Agreement is governed by the laws of the country of registration of the Rights Holder. All disputes shall be settled through negotiations, and if impossible, in the court at the Rights Holder's place of registration.